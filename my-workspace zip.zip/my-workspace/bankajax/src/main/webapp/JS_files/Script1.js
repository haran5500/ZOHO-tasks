/**
 * 
 */

function resetform() {
	alert('hi');
		document.getElementById("loginform").reset();
		alert('byw');
}