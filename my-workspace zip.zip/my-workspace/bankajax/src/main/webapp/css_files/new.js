/**
 * 
 */
 
 function hello()
 {
	alert('hello');
}