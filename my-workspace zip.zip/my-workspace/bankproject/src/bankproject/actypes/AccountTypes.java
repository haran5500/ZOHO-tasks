package bankproject.actypes;

public enum AccountTypes {
	SAVINGS(1),
	DEPOSIT(2),
	CURRENT(3);
	
	AccountTypes(int number)
	{
	
	}
}
