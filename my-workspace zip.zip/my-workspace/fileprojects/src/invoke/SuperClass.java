package invoke;

public class SuperClass {
	String strValue;
	public SuperClass(String inpStr)
	{
		strValue=inpStr;
	}
	
	public String toString()
	{
		return strValue;
	}
}
