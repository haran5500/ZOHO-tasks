package abstractclasses;

import inout.Reader;

public class Duck extends Bird{
	
	public void fly()
	{
		Reader.print("I can't Fly!");	
	}
	
}
