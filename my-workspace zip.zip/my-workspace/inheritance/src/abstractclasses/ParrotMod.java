package abstractclasses;

public class ParrotMod extends BirdAbstract{
	
}
