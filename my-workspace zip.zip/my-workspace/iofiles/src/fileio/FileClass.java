package fileio;
import java.io.File;
import myutilities.Validator;
import userexception.CustomException;

public class FileClass {

//	public File 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
